
package conexaoMySql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBD {
    private static final String bd = "bdPyQuestions";
    private static final String url = "jdbc:mysql://localhost:3306/";
    private static final String user = "root";
    private static final String password = "rEd0803#";

    
    public static Connection obterConexao() throws Exception{
        try{
            Connection conexao = DriverManager.getConnection(url + bd, user, password);
            return conexao;            
        } 
        catch (SQLException e){
            System.err.println(e);

            return null;
        }
    } 
}
