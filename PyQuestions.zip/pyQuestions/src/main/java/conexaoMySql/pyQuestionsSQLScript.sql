create database bdPyQuestions;

use bdPyQuestions;

create table jogadores (
idUser integer not null auto_increment,
email varchar(255) not null, 
username varchar(255) not null unique,
senha varchar(255) not null,
nivel integer not null,
primary key (idUser, email));

create table amigos(                                
idUser integer not null,
idAmigo integer not null,
primary key(idUser, idAmigo),
foreign key (idUser) references jogadores(idUser),
foreign key (idAmigo) references jogadores(idUser));



