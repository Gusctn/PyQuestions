
package principal;


public class AdicionarAmigos {
    private int idUser;
    private int idAmigo;

    public AdicionarAmigos (int idUser, int idAmigo){
        this.idUser = idUser;
        this.idAmigo = idAmigo;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public int getIdAmigo() {
        return idAmigo;
    }

    public void setIdAmigo(int idAmigo) {
        this.idAmigo = idAmigo;
    }
    
    
}
