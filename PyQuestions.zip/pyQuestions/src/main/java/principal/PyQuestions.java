
package principal;

public class PyQuestions {

    public static void main(String[] args) {
        
    }
}
