
package principal;

public class Ranking {
    private int idUser;
    private String username;
    private int nivel;

    public Ranking (int idUser){
        this.idUser = idUser;
    }
    public Ranking (String username, int nivel){
        this.username = username;
        this.nivel = nivel;
    }
    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }
    
    
}
