
package principal;

public class VerNivel {
    private int idUser;

    public VerNivel(int idUser){
        this.idUser = idUser;
    }
    
    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }
    
    
}
