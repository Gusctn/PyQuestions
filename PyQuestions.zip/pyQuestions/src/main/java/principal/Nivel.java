
package principal;

public class Nivel {
    private String pergunta;
    private int resposta;

    public Nivel (String pergunta, int resposta){
        this.pergunta = pergunta;
        this.resposta = resposta;
    }
    
    public String getPergunta() {
        return pergunta;
    }

    public void setPergunta(String pergunta) {
        this.pergunta = pergunta;
    }

    public int getResposta() {
        return resposta;
    }

    public void setResposta(int resposta) {
        this.resposta = resposta;
    }    
}
