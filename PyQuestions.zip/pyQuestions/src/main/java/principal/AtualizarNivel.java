
package principal;

public class AtualizarNivel {
    private int fase;
    private int idUser;

    public AtualizarNivel (int fase, int idUser){
        this.fase = fase;
        this.idUser = idUser;
    }
    
    public int getFase() {
        return fase;
    }

    public void setFase(int fase) {
        this.fase = fase;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }
    
    
}
