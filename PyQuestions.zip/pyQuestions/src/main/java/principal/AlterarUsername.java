
package principal;

public class AlterarUsername {
    private String usernameVelho;
    private String usernameNovo;
    
    public AlterarUsername(String usernameVelho, String usernameNovo){
        this.usernameVelho = usernameVelho;
        this.usernameNovo = usernameNovo;
    }

    public String getUsernameVelho() {
        return usernameVelho;
    }

    public void setUsernameVelho(String usernameVelho) {
        this.usernameVelho = usernameVelho;
    }

    public String getUsernameNovo() {
        return usernameNovo;
    }

    public void setUsernameNovo(String usernameNovo) {
        this.usernameNovo = usernameNovo;
    }
}
