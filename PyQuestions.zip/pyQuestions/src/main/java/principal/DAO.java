
package principal;

import conexaoMySql.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
    
    public int adicionarAmigo (AdicionarAmigos adicionarAmigos) throws Exception{
        String sql = "INSERT INTO bdPyQuestions.amigos (idUser, idAmigo) VALUES (?,?);";
        try(Connection conexao = ConexaoBD.obterConexao(); PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setInt(1,adicionarAmigos.getIdUser());
            ps.setInt(2, adicionarAmigos.getIdAmigo());
            ps.execute();
            return 1;
        }
    }
    
    public int cadastrarJogador (Cadastro cadastro) throws Exception{
        String sql = "INSERT INTO bdPyQuestions.jogadores (email, username, senha, nivel) VALUES (?,?,?,0);";
        try (Connection conexao = ConexaoBD.obterConexao(); PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setString(1,cadastro.getEmail());
            ps.setString(2,cadastro.getUsername());
            ps.setString(3,cadastro.getSenha());
            ps.execute();
            return 1;
        }
    }
        
    public boolean loginSucesso (LogIn login) throws Exception{
        String sql = "SELECT * FROM bdPyQuestions.jogadores WHERE email = ? AND username = ? AND senha = ?;";
        try(Connection conexao = ConexaoBD.obterConexao();PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setString(1, login.getEmail());
            ps.setString(2, login.getUsername());
            ps.setString(3, login.getSenha());
            try(ResultSet rs = ps.executeQuery()){
                return rs.next();
            }
        }       
    }
    public int mostrarNivel (VerNivel verNivel) throws Exception{
        String sql = "SELECT nivel FROM bdPyQuestions.jogadores WHERE idUser = ?;";
        try(Connection conexao = ConexaoBD.obterConexao(); 
                PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setInt(1, verNivel.getIdUser());
            int nivel=0;
            try(ResultSet rs = ps.executeQuery();){
                if(rs.next()) nivel = rs.getInt("nivel");
            }
            return nivel;
        }
    }
    public int mostrarIdUser (Codigo codigo) throws Exception{
        String sql = "SELECT idUser FROM bdPyQuestions.jogadores WHERE email = ? AND username = ?;";
        try(Connection conexao = ConexaoBD.obterConexao(); 
                PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setString(1, codigo.getEmail());
            ps.setString(2,codigo.getUsername());
            int idUser=0;
            try(ResultSet rs = ps.executeQuery();){
                if(rs.next()) idUser = rs.getInt("idUser");
            }
            return idUser;
        }
    }
    public void mostrarRanking (Ranking ranking) throws Exception{
        String sql = "SELECT username, nivel FROM jogadores INNER JOIN amigos ON (amigos.idUser = ? AND amigos.idAmigo = jogadores.idUser);";
        try(Connection conexao = ConexaoBD.obterConexao(); PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setInt(1, ranking.getIdUser());
            ps.execute();

        }
    }
    public int usernameAlterado (AlterarUsername alterarUsername) throws Exception{
        String sql = "UPDATE jogadores SET username = ? WHERE username = ?";
        try(Connection conexao = ConexaoBD.obterConexao();PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setString(1, alterarUsername.getUsernameNovo());
            ps.setString(2, alterarUsername.getUsernameVelho());
            ps.execute();
            return 1;
        }       
    }
    public int senhaAlterada (AlterarSenha alterarSenha) throws Exception{
        String sql = "UPDATE jogadores SET senha = ? WHERE senha = ?";
        try(Connection conexao = ConexaoBD.obterConexao();PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setString(1, alterarSenha.getSenhaNova());
            ps.setString(2, alterarSenha.getSenhaVelha());
            ps.execute();
            return 1;
        }       
    }
    public int atualizarNivel (AtualizarNivel atualizarNivel) throws Exception{
        String sql = "UPDATE jogadores SET nivel = ? WHERE idUser = ?";
        try(Connection conexao = ConexaoBD.obterConexao();PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setInt(1, atualizarNivel.getFase());
            ps.setInt(2, atualizarNivel.getIdUser());
            ps.execute();
            return 1;
        }       
    }
        public Ranking[] obterRanking(Ranking ranking) throws Exception {
        String sql = "SELECT username, nivel FROM jogadores AS j INNER JOIN amigos AS a ON(j.idUser = a.idAmigo and a.idUser = ?);";
        try (Connection conn = ConexaoBD.obterConexao();
             PreparedStatement ps = conn.prepareStatement(sql, 
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);){
            ps.setInt(1, ranking.getIdUser());
            ResultSet rs = ps.executeQuery();
            int totalRanking = rs.last() ? rs.getRow() : 0;
            Ranking[] listaRanking = new Ranking[totalRanking];
            rs.beforeFirst();
            int cont = 0;
            while (rs.next()) {
                String username = rs.getString("username");
                int nivel = rs.getInt("nivel");
                listaRanking[cont++] = new Ranking(username, nivel);
            }
            return listaRanking;
        }
    }
}
