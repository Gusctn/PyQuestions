
package principal;

import conexaoMySql.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
    public int cadastrarJogador (Cadastro cadastro) throws Exception{
        String sql = "INSERT INTO bdPyQuestions.jogadores (email, username, senha) VALUES (?,?,?);";
        try (Connection conexao = ConexaoBD.obterConexao(); PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setString(1,cadastro.getEmail());
            ps.setString(2,cadastro.getUsername());
            ps.setString(3,cadastro.getSenha());
            ps.execute();
            return 1;
        }
    }
        
    public boolean loginSucesso (LogIn login) throws Exception{
        String sql = "SELECT * FROM bdPyQuestions.jogadores WHERE email = ? AND username = ? AND senha = ?;";
        try(Connection conexao = ConexaoBD.obterConexao();PreparedStatement ps = conexao.prepareStatement(sql);){
            ps.setString(1, login.getEmail());
            ps.setString(2, login.getUsername());
            ps.setString(3, login.getSenha());
            try(ResultSet rs = ps.executeQuery()){
                return rs.next();
            }
        }       
    }
    
}
