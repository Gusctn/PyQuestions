
package principal;

public class AlterarSenha {
    private String senhaVelha;
    private String senhaNova;

    public AlterarSenha (String senhaVelha, String senhaNova){
        this.senhaVelha = senhaVelha;
        this.senhaNova = senhaNova;
    }
    public String getSenhaVelha() {
        return senhaVelha;
    }

    public void setSenhaVelha(String senhaVelha) {
        this.senhaVelha = senhaVelha;
    }

    public String getSenhaNova() {
        return senhaNova;
    }

    public void setSenhaNova(String senhaNova) {
        this.senhaNova = senhaNova;
    }
    
    
}
